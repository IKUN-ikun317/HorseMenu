#include "Folder.hpp"
#include "FileMgr.hpp"

namespace YimMenu
{
    Folder::Folder(const std::filesystem::path& path) :
        BaseObj(path)
    {

    }
}