#pragma once

namespace YimMenu
{
	void PrintProtoBuffer(void* buffer, int size, void* def);
}