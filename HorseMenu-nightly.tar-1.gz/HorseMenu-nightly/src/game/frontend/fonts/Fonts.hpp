#pragma once

namespace YimMenu::Fonts
{
	extern const uint8_t MainFont[78948];
}