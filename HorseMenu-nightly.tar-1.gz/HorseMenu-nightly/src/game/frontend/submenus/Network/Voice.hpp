#pragma once
#include "game/frontend/items/Items.hpp"
#include "core/frontend/manager/Category.hpp"

namespace YimMenu::Submenus
{
	std::shared_ptr<Category> BuildVoiceMenu();
}