#pragma once
#include "core/frontend/manager/UIManager.hpp"

namespace YimMenu::Submenus
{
	class Debug : public Submenu
	{
	public:
		Debug();
	};
}