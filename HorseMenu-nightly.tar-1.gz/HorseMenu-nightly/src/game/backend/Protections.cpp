#include "Protections.hpp"

namespace YimMenu
{

}