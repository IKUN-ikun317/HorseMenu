#pragma once

namespace YimMenu::Submenus
{
	void RenderTrainsMenu();
}